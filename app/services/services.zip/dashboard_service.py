from app.services.catalogos_service import get_catalogos_service
from app.services.deudas_service import get_deudas, get_deudas_activas
from app.services.networth_service import get_neto, get_networth, get_saldos
from app.services.resumen_service import get_resumen_mes, get_resumen_semana


def get_dashboard(user_id: int) -> dict:
    resumen_mes = get_resumen_mes(user_id)
    resumen_semana = get_resumen_semana(user_id)
    saldos = get_saldos(user_id)
    networth = get_networth(user_id)
    neto = get_neto(user_id)
    deudas = get_deudas(user_id)
    deudas_activas = get_deudas_activas(user_id)
    catalogos = get_catalogos_service(user_id)

    total_deudas = 0.0
    for d in deudas_activas:
        total_deudas += float(d.get("saldo", 0) or 0)

    return {
        "user_id": user_id,
        "resumen_mes": resumen_mes,
        "resumen_semana": resumen_semana,
        "saldos": saldos,
        "networth": networth,
        "neto": neto,
        "deudas": deudas,
        "deudas_activas": deudas_activas,
        "total_deudas": round(total_deudas, 2),
        "catalogos": catalogos,
    }