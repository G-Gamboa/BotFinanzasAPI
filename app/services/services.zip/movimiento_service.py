from app.config import BOLSA_NORMAL, SHEET_EGRESOS, SHEET_INGRESOS, SHEET_MOVIMIENTOS
from app.core.validators import validate_flow_data
from app.services.sheets_service import open_user_spreadsheet, save_movimiento

from fastapi import APIRouter, HTTPException

from app.services.movimientos_service import create_movimiento

router = APIRouter(prefix="/movimientos", tags=["movimientos"])


@router.post("")
def crear_movimiento(payload: dict):
    try:
        return create_movimiento(payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def validar_metodo_egreso(data: dict):
    if data.get("tipo") == "EGR":
        metodo = (data.get("metodo") or "").strip()
        permitidos = {"Efectivo", "Transferencia"}
        if metodo not in permitidos:
            raise ValueError("Para egresos solo se permite Efectivo o Transferencia.")

def create_movimiento(data: dict, sheet_id: str) -> dict:
    validar_metodo_egreso(data)
    save_movimiento(data)

    if data['tipo'] == 'ING':
        sh.worksheet(SHEET_INGRESOS).append_row([
            data['fecha'],
            data.get('fuente', ''),
            data.get('categoria', ''),
            data['monto'],
            data.get('metodo', ''),
            data.get('banco', ''),
            data.get('nota', ''),
        ], value_input_option='USER_ENTERED')
    elif data['tipo'] == 'EGR':
        sh.worksheet(SHEET_EGRESOS).append_row([
            data['fecha'],
            data.get('categoria', ''),
            data['monto'],
            data.get('metodo', ''),
            data.get('banco', ''),
            data.get('nota', ''),
        ], value_input_option='USER_ENTERED')
    else:
        sh.worksheet(SHEET_MOVIMIENTOS).append_row([
            data['fecha'],
            data.get('bolsa_remitente', BOLSA_NORMAL),
            data.get('remitente', ''),
            data.get('bolsa_destino', BOLSA_NORMAL),
            data.get('destino', ''),
            data.get('persona_prestamo', ''),
            data['monto'],
            data.get('monto_destino', 0),
            data.get('nota', ''),
        ], value_input_option='USER_ENTERED')

    return {'saved': True, 'tipo': data['tipo']}
